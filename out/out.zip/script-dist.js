/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
var translations = {
  en: {
    pipTitle: "Click to activate Picture-in-Picture mode",
    pipText: "Click anywhere on the video to activate Picture-in-Picture mode. When you minimize the window, the video will shrink and you'll still have it on the screen",
    lastTalker1: "Last Talker",
    lastTalker2: "Second to last speaker",
    lastTalker3: "Third to last speaker",
    willSendMsg: "Sends a private message: ",
    msgNotSharing: "You are not sharing the screen",
    msgNotSharingLong: "You are not sharing the screen. You must always share the screen in our class.",
    msgYouHere: "Are you here?",
    msgYouHear: "Can you hear us?",
    msgRestart: "Restart Remotto",
    msgRestartLong: "Restart Remotto, hopefully that will solve your problems",
    refreshRemotto: "Refresh all users' screens",
    youNotSharing: "You're not sharing your screen, you must share the whole screen all the time in our class"
  },
  cs: {
    pipTitle: "Klikni pro aktivaci Picture-in-Picture módu",
    pipText: "Klikni kdekoli na video pro aktivaci Picture-in-Picture módu. Když minimalizuješ okno, video se zmenší a budeš ho mít pořád na obrazovce.",
    lastTalker1: "Poslední mluvící",
    lastTalker2: "Předposlední mluvící",
    lastTalker3: "Předpředposlední mluvící",
    willSendMsg: "Pošle soukromou zprávu: ",
    msgNotSharing: "Nesdílíš obrazovku",
    msgNotSharingLong: "Nesdílíš obrazovku. V hodinách je nutné stále sdílet obrazovku.",
    msgYouHere: "Jsi tady?",
    msgYouHear: "Slyšíš nás?",
    msgRestart: "Restartuj Remotto",
    msgRestartLong: "Restartuj Remotto, snad to vyřeší Tvé trable",
    refreshRemotto: "Refresh obrazovek všech uživatelů",
    youNotSharing: "Nesdílíš obrazovku, v našich hodinách je třeba neustále sdílet celou obrazovku."
  },
  sk: {
    pipTitle: "Kliknutím aktivujete režim Picture-in-Picture",
    pipText: "Kliknutím kdekoľvek na video aktivujete režim Picture-in-Picture. Keď okno minimalizujete, video sa zmenší a budete ho mať stále na obrazovke.",
    lastTalker1: "Posledný hovoriaci",
    lastTalker2: "Predposledný hovoriaci",
    lastTalker3: "Predpredposledný hovoriaci",
    willSendMsg: "Odošle súkromnú správu: ",
    msgNotSharing: "Nezdieľate obrazovku",
    msgNotSharingLong: "Nezdieľate obrazovku. Stále musíte zdieľať obrazovku v našich hodinách.",
    msgYouHere: "Ste tu?",
    msgYouHear: "Počujete nás?",
    msgRestart: "Reštartujte Remotto",
    msgRestartLong: "Reštartujte Remotto, dúfajme, že to vyrieši vaše problémy.",
    refreshRemotto: "Obnoviť obrazovky všetkých používateľov",
    youNotSharing: "Nezdieľate svoju obrazovku, musíte zdieľať celú obrazovku po celý čas v našich hodinách."
  },
  de: {
    pipTitle: "Klicken Sie, um den Bild-in-Bild-Modus zu aktivieren",
    pipText: "Klicken Sie irgendwo auf das Video, um den Bild-in-Bild-Modus zu aktivieren. Wenn Sie das Fenster minimieren, wird das Video verkleinert und bleibt trotzdem auf dem Bildschirm sichtbar.",
    lastTalker1: "Letzter Redner",
    lastTalker2: "Vorletzter Sprecher",
    lastTalker3: "Drittletzter Sprecher",
    willSendMsg: "Sendet eine private Nachricht: ",
    msgNotSharing: "Sie teilen den Bildschirm nicht",
    msgNotSharingLong: "Du teilst den Bildschirm nicht. Sie müssen den Bildschirm in unserer Klasse immer teilen.",
    msgYouHere: "Bist du hier?",
    msgYouHear: "Können Sie uns hören?",
    msgRestart: "Remotto neu starten",
    msgRestartLong: "Starten Sie Remotto neu, hoffentlich löst das Ihre Probleme",
    refreshRemotto: "Aktualisieren Sie die Bildschirme aller Benutzer",
    youNotSharing: "Du teilst deinen Bildschirm nicht, du musst in unserer Klasse immer den ganzen Bildschirm teilen"
  }
};
function translate(key) {
  var language = localStorage.getItem("language") || "en";

  // trim "-" from "en-US"
  if (language.length > 2) {
    language = language.substring(0, 2);
  }

  // detect if the language is supported
  if (translations[language] == undefined) {
    language = "en";
  }
  var generatedTranslation = translations[language][key] || undefined;
  if (generatedTranslation == undefined) {
    generatedTranslation = "";
  }
  return generatedTranslation;
}
/* harmony default export */ __webpack_exports__["default"] = (translate);

/***/ }),
/* 2 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _translate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);

var statsTalking = ["", "", ""];
function findTalking(track, name) {
  // we don't want videos or others
  if (track.type != "audio") return;

  // skip if muted -1 or if not talking 0
  if (track.audioLevel <= 0) return;
  var isInStats = false;
  var isLast = false;
  for (var i = 0; i < statsTalking.length; i++) {
    if (statsTalking[i] == name) {
      isInStats = true;
      if (i == 0) {
        isLast = true;
      }
    }
  }
  if (isInStats && !isLast) {
    var index = statsTalking.indexOf(name);
    if (index > -1) {
      statsTalking.splice(index, 1);
    }
    statsTalking.push(name);
  }
  if (!isInStats) {
    statsTalking.push(name);
    if (statsTalking.length > 3) {
      statsTalking.shift();
    }
    updateLastTalking();
  }
}
function updateLastTalking() {
  var lastTalkingOne = document.querySelector("#lastTalkingOne");
  var lastTalkingTwo = document.querySelector("#lastTalkingTwo");
  var lastTalkingThree = document.querySelector("#lastTalkingThree");
  if (lastTalkingOne) {
    lastTalkingOne.innerHTML = statsTalking[0];
  }
  if (lastTalkingTwo) {
    lastTalkingTwo.innerHTML = statsTalking[1];
  }
  if (lastTalkingThree) {
    lastTalkingThree.innerHTML = statsTalking[2];
  }
}
function createLastTalkingElements() {
  var lastTalking = document.createElement("div");
  lastTalking.id = "lastTalking";

  // lastTalking subelements
  var lastTalkingOne = document.createElement("div");
  lastTalkingOne.id = "lastTalkingOne";
  var lastTalkingTwo = document.createElement("div");
  lastTalkingTwo.id = "lastTalkingTwo";
  var lastTalkingThree = document.createElement("div");
  lastTalkingThree.id = "lastTalkingThree";
  lastTalkingOne.title = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("lastTalker1");
  lastTalkingTwo.title = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("lastTalker2");
  lastTalkingThree.title = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("lastTalker3");
  lastTalking.appendChild(lastTalkingOne);
  lastTalking.appendChild(lastTalkingTwo);
  lastTalking.appendChild(lastTalkingThree);
  document.body.appendChild(lastTalking);
}
/* harmony default export */ __webpack_exports__["default"] = ({
  find: findTalking,
  create: createLastTalkingElements
});

/***/ }),
/* 3 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _translate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);


// This function ONLY works for iFrames of the same origin as their parent
function iFrameReady(iFrame, fn) {
  var timer;
  var fired = false;
  function ready() {
    if (!fired) {
      fired = true;
      clearTimeout(timer);
      fn.call(this);
    }
  }
  function readyState() {
    if (this.readyState === "complete") {
      ready.call(this);
    }
  }

  // cross platform event handler for compatibility with older IE versions
  function addEvent(elem, event, fn) {
    if (elem.addEventListener) {
      return elem.addEventListener(event, fn);
    } else {
      return elem.attachEvent("on" + event, function () {
        return fn.call(elem, window.event);
      });
    }
  }

  // use iFrame load as a backup - though the other events should occur first
  addEvent(iFrame, "load", function () {
    ready.call(iFrame.contentDocument || iFrame.contentWindow.document);
  });
  function checkLoaded() {
    var doc = iFrame.contentDocument || iFrame.contentWindow.document;
    // We can tell if there is a dummy document installed because the dummy document
    // will have an URL that starts with "about:".  The real document will not have that URL
    if (doc.URL.indexOf("about:") !== 0) {
      if (doc.readyState === "complete") {
        ready.call(doc);
      } else {
        // set event listener for DOMContentLoaded on the new document
        addEvent(doc, "DOMContentLoaded", ready);
        addEvent(doc, "readystatechange", readyState);
      }
    } else {
      // still same old original document, so keep looking for content or new document
      timer = setTimeout(checkLoaded, 1);
    }
  }
  checkLoaded();
}
function onRefreshButtonClick() {
  // button to force refresh
  var refreshButton = document.createElement("button");
  refreshButton.id = "refreshButton";
  refreshButton.title = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("refreshRemotto");
  document.body.appendChild(refreshButton);

  //@ts-ignore it's not null, it was created before calling this function
  document.getElementById("refreshButton").addEventListener("click", function () {
    var refreshIframe = document.createElement("iframe");
    refreshIframe.id = "refreshIframe";
    refreshIframe.setAttribute("sandbox", "allow-same-origin allow-scripts");
    refreshIframe.src = window.location.href;
    document.body.appendChild(refreshIframe);
    iFrameReady(document.getElementById("refreshIframe"), function () {
      setTimeout(function () {
        document.body.removeChild(refreshIframe);
      }, 6000);
    });
  });
}
/* harmony default export */ __webpack_exports__["default"] = ({
  create: onRefreshButtonClick
});

/***/ }),
/* 4 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _translate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);

var isMenuShown = false;
function sendPrivateMessage(targetId, message) {
  try {
    //@ts-ignore it's on the website
    APP.conference._room.sendPrivateTextMessage(targetId, message);
  } catch (error) {
    console.warn("error sending private message", error);
  }
}
function createContextMenu() {
  var menu = document.createElement("ul");
  menu.className = "menu";
  document.body.appendChild(menu);
}
function hideContextMenu() {
  var menu = document.querySelector(".menu");
  menu.style.display = "none";
  isMenuShown = false;
}
function participantContextMenu(videocontainer, event) {
  function createMenuItem(shortMessage, longMessage) {
    var menuItem = document.createElement("li");
    menuItem.className = "menu-item";
    var linkItem = document.createElement("a");
    linkItem.href = "#";
    linkItem.innerHTML = shortMessage;
    linkItem.title = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("willSendMsg") + longMessage;
    linkItem.addEventListener("click", function (clickEvent) {
      clickEvent.preventDefault();
      sendPrivateMessage(targetId, longMessage);
      hideContextMenu();
    });
    menuItem.appendChild(linkItem);
    menu.appendChild(menuItem);
  }

  // prevent if clicking on ourselves
  // console.log(videocontainer.id);
  var videoId = videocontainer.id;
  if (videoId === "localVideoContainer") return;
  if (videoId === "largeVideoContainer") return;
  event.preventDefault();
  var menu = document.querySelector(".menu");
  menu.style.display = "block";
  menu.style.left = event.clientX + "px";
  menu.style.top = event.clientY + "px";

  // remove all previous menu items
  while (menu.firstChild) {
    menu.removeChild(menu.firstChild);
  }
  // add new menu items
  var targetId = videoId.split("_")[1];
  createMenuItem((0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgNotSharing"), (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgNotSharingLong"));
  createMenuItem((0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgYouHere"), (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgYouHere"));
  createMenuItem((0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgYouHear"), (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgYouHear"));
  createMenuItem((0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgRestart"), (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("msgRestartLong"));
  isMenuShown = true;
}
function addCustomContextMenu() {
  createContextMenu();
  setInterval(function () {
    try {
      document.querySelectorAll(".videocontainer").forEach(function (videocontainer) {
        videocontainer.addEventListener("contextmenu", function (event) {
          return participantContextMenu(videocontainer, event);
        });
      });
    } catch (error) {
      console.warn("test error", error);
    }
  }, 1000);
  document.addEventListener("click", function (event) {
    if (isMenuShown) hideContextMenu();
  });
}
/* harmony default export */ __webpack_exports__["default"] = (addCustomContextMenu);

/***/ }),
/* 5 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _translate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);

var wasModeratorScreenForced = false;
function toggleMicrophone() {
  // get the current state of the microphone
  // @ts-ignore
  var currentState = APP.conference.isLocalAudioMuted();

  // toggle the state of the microphone in the remotto
  // @ts-ignore
  APP.conference.toggleAudioMuted(!currentState);

  // toggle the state inside Picture-in-Picture window
  // @ts-ignore
  navigator.mediaSession.setMicrophoneActive(currentState);
}
function showPictureInPicture(moderatorId) {
  var videoID = "#remoteVideo_".concat(moderatorId, "-video-1");

  // Listen for visibility change event
  document.addEventListener("visibilitychange", function () {
    // Check if the document is hidden
    if (document.hidden) {
      // Check if picture-in-picture is supported
      var video = document.querySelector(videoID);
      if (video !== undefined && video !== null && document.pictureInPictureEnabled) {
        // Request picture-in-picture mode
        try {
          if (document.pictureInPictureElement) return;
          if (video.readyState === 4) {
            // it's loaded
            console.log("video is loaded");
            video.requestPictureInPicture();
          }
          video.addEventListener("leavepictureinpicture", function (event) {
            // alert("Picture-in-Picture mode has been closed");
            createPiPButton(moderatorId);
            var pictureInPictureButton = document.querySelector("#pictureInPictureButton");
            pictureInPictureButton.style.display = "block";
          });
        } catch (error) {
          console.warn("error requesting picture in picture", error);
        }
      }

      // if picture is disabled
      if (!document.pictureInPictureEnabled) {
        console.info("picture in picture is disabled");
      }
    }
  });
}
function createPiPButton(moderatorId) {
  var largeVideo = document.querySelector("#largeVideoElementsContainer");
  if ((largeVideo === null || largeVideo === void 0 ? void 0 : largeVideo.style.visibility) !== "visible") {
    // at the beginning, show the moderator's video

    // skip it if it was already shown after page refresh
    if (wasModeratorScreenForced) {
      return;
    }
    var videoID = "#remoteVideo_".concat(moderatorId, "-video-1");
    var video = document.querySelector(videoID);
    video.click();
    wasModeratorScreenForced = true;
  } else {
    // check if pictureInPicture is enabled, otherwise dont create the button
    if (!document.pictureInPictureEnabled) {
      return;
    }

    // add new element to the largeVideo
    // create element inside the largeVideo's parent
    var largeVideoWrapper = document.querySelector("#largeVideoWrapper");

    // check if the element already exists
    var pictureInPictureButton = document.querySelector("#pictureInPictureButton");

    // if the element doesnt exist, create it
    if (!pictureInPictureButton) {
      pictureInPictureButton = document.createElement("div");
      pictureInPictureButton.id = "pictureInPictureButton";
      pictureInPictureButton.title = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("pipTitle");

      // when clicked, hide the pictureInPictureButton
      pictureInPictureButton.addEventListener("click", function () {
        pictureInPictureButton.style.display = "none";
      });

      // add div inside the pictureInPictureButton
      var pictureInPictureButtonInner = document.createElement("div");
      pictureInPictureButtonInner.id = "pictureInPictureButtonInner";
      pictureInPictureButtonInner.textContent = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("pipText");
      pictureInPictureButton.appendChild(pictureInPictureButtonInner);
      largeVideoWrapper.appendChild(pictureInPictureButton);
      checkIfMonitorExtended(pictureInPictureButton);
    }
  }
  function checkIfMonitorExtended(pictureInPictureButton) {
    var windowScreen = window.screen;
    if (!windowScreen) return;
    if (windowScreen.isExtended) {
      pictureInPictureButton.style.display = "none";
    }
  }
}
function createPictureInPicture(moderatorId) {
  showPictureInPicture(moderatorId);

  // Add a button to the picture-in-picture mode via MediaSession's setActionHandler() method
  if ("mediaSession" in navigator) {
    // @ts-ignore
    var currentState = APP.conference.isLocalAudioMuted();

    // set the initial state of the microphone
    // has to be opposite due to the isLocalAudioMuted() function
    // @ts-ignore
    navigator.mediaSession.setMicrophoneActive(!currentState);

    // @ts-ignore
    navigator.mediaSession.setActionHandler("togglemicrophone", function () {
      toggleMicrophone();
    });
  }
  createPiPButton(moderatorId);
}
/* harmony default export */ __webpack_exports__["default"] = (createPictureInPicture);

/***/ }),
/* 6 */
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _translate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);

function toggleInfoNotSharingScreen() {
  var sharingInfo = document.querySelector("#sharingInfo");
  if (!sharingInfo) return;

  // @ts-ignore
  var isSharingScreen = APP.conference.isSharingScreen;
  if (isSharingScreen) {
    sharingInfo.style.display = "none";
  } else {
    sharingInfo.style.display = "block";
  }
}
function showInfoIfNotSharingScreen() {
  // create element #sharingInfo
  var sharingInfo = document.querySelector("#sharingInfo");
  if (!sharingInfo) {
    var _sharingInfo = document.createElement("div");
    _sharingInfo.id = "sharingInfo";
    _sharingInfo.innerHTML = (0,_translate__WEBPACK_IMPORTED_MODULE_0__["default"])("youNotSharing");

    // on click
    _sharingInfo.addEventListener("click", function () {
      // @ts-ignore
      APP.conference.toggleScreenSharing();
    });
    var largeVideoWrapper = document.querySelector("#videoconference_page");
    largeVideoWrapper.appendChild(_sharingInfo);
  }
  toggleInfoNotSharingScreen();
}
/* harmony default export */ __webpack_exports__["default"] = (showInfoIfNotSharingScreen);

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
!function() {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ts_translate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _ts_findWhosTalking__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
/* harmony import */ var _ts_addRefreshButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
/* harmony import */ var _ts_addCustomContextMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4);
/* harmony import */ var _ts_showPictureInPicture__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5);
/* harmony import */ var _ts_showInfoIfNotSharingScreen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6);
// imports






var hasRoomModerator = false;
function whenMemberIsModerator(member) {
  if (member._role === "moderator") {
    hasRoomModerator = true;
    var moderatorId = member._id;
    (0,_ts_showPictureInPicture__WEBPACK_IMPORTED_MODULE_4__["default"])(moderatorId);
  }
}
function detectConnectedMembers() {
  try {
    //@ts-ignore it's on the website
    var members = APP.conference.listMembers();
    for (var membersIndex = 0; membersIndex < members.length; membersIndex++) {
      var member = members[membersIndex];

      // find who is talking
      var name = member._displayName;
      var tracks = member._tracks;
      for (var trackIndex = 0; trackIndex < tracks.length; trackIndex++) {
        var track = tracks[trackIndex];
        _ts_findWhosTalking__WEBPACK_IMPORTED_MODULE_1__["default"].find(track, name);
      }

      // find if the member is moderator
      whenMemberIsModerator(member);
    }
  } catch (error) {}
}
function createElementsOnStart() {
  _ts_addRefreshButton__WEBPACK_IMPORTED_MODULE_2__["default"].create();
}
function createElementsOnStartModerator() {
  _ts_findWhosTalking__WEBPACK_IMPORTED_MODULE_1__["default"].create();
}

// start code
createElementsOnStart();
setInterval(function () {
  detectConnectedMembers();
  (0,_ts_showInfoIfNotSharingScreen__WEBPACK_IMPORTED_MODULE_5__["default"])();
}, 1000);

// set timeout so the moderator can be detected
setTimeout(function () {
  if (!hasRoomModerator) {
    // create elements on start
    createElementsOnStartModerator();

    // right click menu
    (0,_ts_addCustomContextMenu__WEBPACK_IMPORTED_MODULE_3__["default"])();
  }
}, 1000);
}();
/******/ })()
;